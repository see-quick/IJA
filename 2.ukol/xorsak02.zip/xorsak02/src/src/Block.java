package src;


import errorHandler.MyException;
import src.port.MyPortIn;
import src.port.MyPortOut;

import java.util.Map;

public class Block {

    private MyPortIn[] portsIn;
    private MyPortOut[] portsOut;

    public Block(String[][] portsIn, String[][] portsOut) {

        this.portsIn = new MyPortIn[portsIn.length];
        this.portsOut = new MyPortOut[portsOut.length];

        for (int i = 0; i < portsIn.length; i++) {
            this.portsIn[i] = new MyPortIn(portsIn[i]);
        }

        for (int i = 0; i < portsOut.length; i++) {
            this.portsOut[i] = new MyPortOut(portsOut[i]);
        }
    }

    public void printData() {

        System.out.println("--------------------");
        System.out.println("INPORTS:");
        for (int i = 0; i < portsIn.length; i++) {
            System.out.println(portsIn[i].getData());
        }

        System.out.println("OUTPORTS:");
        for (int i = 0; i < portsOut.length; i++) {
            System.out.println(portsOut[i].getData());
        }
        System.out.println("--------------------");
    }

    public void setInputData(){

    }

    public java.lang.Double getPortInValue(int portIndex, String key) throws MyException{
        if(portIndex < 0 || portIndex >= getNumberOfInputPorts()){
            throw new MyException("Wrong index of input ports getPortInValue()");
        }

        Map<String, Double> map = getPortsIn()[portIndex].getData();
        if(map.containsKey(key)){
            return map.get(key);
        } else {
            throw new MyException("Wrong key when getting a value from a port by getPortInValue()");
        }
    }

    public java.lang.Double getPortOutValue(int portIndex, String key) throws MyException{
        if(portIndex < 0 || portIndex >= getNumberOfOutputPorts()){
            throw new MyException("Wrong index of input ports getPortInValue()");
        }

        Map<String , Double> map = getPortsOut()[portIndex].getData();
        if(map.containsKey(key)){
            return map.get(key);
        } else {
            throw new MyException("Wrong key when getting a value from a port by getPortInValue()");
        }
    }


    public int getNumberOfInputPorts(){
        return this.portsIn.length;
    }

    public int getNumberOfOutputPorts(){
        return this.portsOut.length;
    }

    public void setPortInValues(Map<String, Double> data, int index) throws MyException {
        if((index < 0 || index >= getNumberOfInputPorts())) {
            throw new MyException("Wrong index of input ports setPortInValues()");
        }
        portsIn[index].setData(data);
    }

    public void setPortOutValues(Map<String, Double> data, int index) throws MyException {
        if((index < 0 || index >= getNumberOfInputPorts())) {
            throw new MyException("Wrong index of output ports setPortOutValues()");
        }
        portsOut[index].setData(data);
    }

    public void calculate() throws MyException {

    }

    public MyPortIn[] getPortsIn() {
        return portsIn;
    }

    public MyPortOut[] getPortsOut() {
        return portsOut;
    }
}














    /*
    // -------------------------------------------------------

    // arrraylist of ports
    private ArrayList<MyPort> ports = new ArrayList<>();

    // block will always have a ports
    public Block(ArrayList<MyPort> ports) {
        this.ports = ports;
    }

    // control in out -> so it can not happen like in in or out out
    // create a method....


    public static boolean controlInOut(MyPort port1 , MyPort port2){

        if(port1 instanceof InPort && port2 instanceof OutPort){
            return true;
        }
        else if(port2 instanceof InPort && port1 instanceof  OutPort){
            return true;
        }
        else{
            return false;
        }
    }


    // Myport... args you can type how much you like ports
    private void calcuteInputToOutput(MyPort... port){

        double resultOfCalculation = 0;

        // for each Inport
        for(MyPort mp : port){
            if (mp instanceof InPort) {
                mp.getValue(); // value of port
                // TODO: you do that pattern(vzorec)
                // TODO: save that value to local temp
            }
        }
        // for each Outport
        for (MyPort mp: port){
            // TODO: that resultofCalculation will rewrite all the results... so if first in will be like 10 -> you will get all outputs 10
            if(mp instanceof OutPort){
                mp.setValue(resultOfCalculation);
            }
        }
    }

    private void editBlock(){
        // TODO: miesto -> polohu na scheme(x,y)...
    }

    */


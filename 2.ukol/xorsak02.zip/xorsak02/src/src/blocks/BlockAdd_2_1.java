package src.blocks;

import errorHandler.MyException;
import src.Block;

import java.util.HashMap;
import java.util.Map;

public class BlockAdd_2_1 extends Block {

    static private final String[][] portsIn = new String[][]{{"T1"},{"T1"}};
    static private final String[][] portsOut = new String[][]{{"T1"}};

    public BlockAdd_2_1() throws MyException {

        super(portsIn, portsOut);

        if (super.getNumberOfInputPorts() != 2 || super.getNumberOfOutputPorts() != 1) {
            throw new MyException("Wrong number of ports was entered when constructing a BlockAdd_2_1");
        }
    }

    @Override
    public void calculate() throws MyException {

        java.lang.Double temp1 = getPortInValue(0, "T1");
        java.lang.Double temp2 = getPortInValue(1, "T1");

        if(temp1 == null || temp2 == null){
            throw new MyException("Set values in input ports first before calling calculate()");
        }

        double result = temp1 + temp2;
        Map<String, Double> map = new HashMap<String, Double>();
        map.put("T1", result);

        super.setPortOutValues(map, 0);
    }

    public void setInputDataOnPort0(double T1value) throws MyException {

        Map<String, Double> mapPort = new HashMap<String, Double>();
        mapPort.put("T1", T1value);
        super.setPortInValues(mapPort, 0);
    }

    public void setInputDataOnPort1(double T1value) throws MyException {

        Map<String, Double> mapPort = new HashMap<String, Double>();
        mapPort.put("T1", T1value);
        super.setPortInValues(mapPort, 1);
    }
}

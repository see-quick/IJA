package src.port;

import src.MyPort;

public class MyPortOut extends MyPort {



    public MyPortOut(String[] args) {
        super(args);
    }



    /*
    private int quatity;

    public OutPort(String name, double value , int quantity) {
        super(name, value);
        this.quatity = quantity;
    }

    public int getQuatity() {
        return quatity;
    }

    public void setQuatity(int quatity) {
        this.quatity = quatity;
    }

    // data from ports
    @Override
    public String getName() {
        return super.getName();
    }

    @Override
    public void setName(String name) {
        super.setName(name);
    }

    @Override
    public double getValue() {
        return super.getValue();
    }

    @Override
    public void setValue(double value) {
        super.setValue(value);
    }

    @Override
    public void editPort() {
        super.editPort();
        // TODO : quantity... GUI
    }/
    */
}

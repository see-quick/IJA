package src;

import java.util.ArrayList;

public class Scheme {

    // array of blocks
    private ArrayList<Block> arrayOfBlocks = new ArrayList<>();
    // array of links
    // TODO : here has to be LINKER...
    // it has to be unique // control name with some cycle if (name = name) then throw err
    String nameOfScheme;


    // empty constructor....when you calling scheme it might be empty
    public Scheme() {
    }



    private void calculate(){
            // TODO : 4.bod v specifikacii...
    }

    private void createScheme(Scheme scheme){
    }

    private void editScheme(Scheme scheme){

    }

    private void saveScheme(Scheme scheme){

    }

    private void loadScheme(Scheme scheme){

    }



}

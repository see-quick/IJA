import errorHandler.MyException;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import src.blocks.BlockAdd_2_1;

public class Tests {

    BlockAdd_2_1 blockAdd_2_1;

    @Before
    public void initObjects() throws MyException {
        blockAdd_2_1 = new BlockAdd_2_1();
    }

    @Test
    public void testNumberOfInputPort() throws MyException {
        Assert.assertEquals("Testing if the blocks has two inputs...", blockAdd_2_1.getNumberOfInputPorts(), 2);
        Assert.assertTrue("Testing if the blocks has two inputs...", blockAdd_2_1.getNumberOfInputPorts() == 2);
        Assert.assertFalse(blockAdd_2_1.getNumberOfInputPorts() == 3);
    }


    @Test
    public void testNumberOutputPort() throws MyException {
        Assert.assertEquals("testNumberOutputPort->Test", blockAdd_2_1.getNumberOfOutputPorts(), 1);
        Assert.assertTrue(blockAdd_2_1.getNumberOfOutputPorts() == 1);
        Assert.assertFalse(blockAdd_2_1.getNumberOfOutputPorts() == 5);
    }

    @Test
    public void InsertData() throws MyException {

        blockAdd_2_1.setInputDataOnPort0(3.3);
        blockAdd_2_1.setInputDataOnPort1(1.8);
        Assert.assertEquals("InsertData->Test", blockAdd_2_1.getPortInValue(0, "T1"), 3.3, 0.000001);
        Assert.assertEquals("InsertData->Test", blockAdd_2_1.getPortInValue(1, "T1"), 1.8, 0.000001);
        Assert.assertFalse(blockAdd_2_1.getPortInValue(0, "T1") == 1.8);
        Assert.assertFalse(blockAdd_2_1.getPortInValue(1, "T1") == 3.3);

    }


    @Test
    public void Calculate1() throws MyException {

        blockAdd_2_1.setInputDataOnPort0(3.3);
        blockAdd_2_1.setInputDataOnPort1(1.8);
        Assert.assertEquals("InsertData before calculating->Test", blockAdd_2_1.getPortInValue(0, "T1"), 3.3, 0.000001);
        Assert.assertFalse(blockAdd_2_1.getPortInValue(0, "T1") == 1.8);
        Assert.assertFalse(blockAdd_2_1.getPortInValue(1, "T1") == 3.3);
        blockAdd_2_1.calculate();
        Assert.assertEquals("Calculate->Test", blockAdd_2_1.getPortOutValue(0, "T1"), 5.1, 0.000001);
        Assert.assertFalse(blockAdd_2_1.getPortOutValue(0, "T1") != 5.1);
    }

    @Test
    public void Calculate2() throws MyException{

        blockAdd_2_1.setInputDataOnPort0(101010.22);
        blockAdd_2_1.setInputDataOnPort1(213213.11);

        Assert.assertEquals("InsertData before calculating->Test", blockAdd_2_1.getPortInValue(0, "T1"), 101010.22, 0.000001);
        Assert.assertFalse(blockAdd_2_1.getPortInValue(0, "T1") == 213213.11);
        Assert.assertFalse(blockAdd_2_1.getPortInValue(1, "T1") == 101010.22);
        blockAdd_2_1.calculate();
        Assert.assertEquals("Calculate->Test", blockAdd_2_1.getPortOutValue(0, "T1"), 314223.33, 0.000001);
        Assert.assertFalse(blockAdd_2_1.getPortOutValue(0, "T1") == 22211.22);

    }





}
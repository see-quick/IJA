package src;

import src.port.MyPortIn;
import src.port.MyPortOut;

public class Link {

    // 5.Další podmínky...
    private String state;

    // TODO : there we have to control ("systém kontroluje kompatibilitu vstupního a výstupního portu propoje (stejný typ dat)")

    private MyPortIn[] portsIn;
    private MyPortOut[] portsOut;



}

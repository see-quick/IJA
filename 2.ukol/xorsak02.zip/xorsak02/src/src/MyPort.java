package src;

import errorHandler.MyException;

import java.util.HashMap;
import java.util.Map;

public class MyPort {


    Map<String , Double> data = new HashMap<String , Double>();

    // insert : data.put("Sirka",5.0);
    // get    : data.get("Sirka");


    public MyPort(String[] args){
        for ( String arg : args){
            data.put(arg, null);
        }
    }

    public Map<String, Double> getData() {
        return data;
    }

    public double getValueByKey(String key){
        return getData().get(key);
    }

    public void setData(Map<String, Double> data) throws MyException {

        if(this.data.keySet().equals(data.keySet())){
            this.data = data;
        }
        else{
            throw new MyException("Port incompatibile types");
        }
    }
}

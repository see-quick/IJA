import errorHandler.MyException;
import src.blocks.BlockAdd_2_1;


public class main {


    public static void main(String[] args) throws MyException {

//        Map<String,Double> map = new HashMap<String , Double>();
//        map.put("Sirka",12.2);
//        map.put("Vyska",50.4);
//
//        Block block = new Block(new String[][]{{"Sirka", "Vyska"}, {"Vyska", "Objem"}}, new String[][]{{"ID", "Vypocet"}, {"EE", "lala"}});
//       // block.printData();
//
//
//        block.setPortInValues(map,0);
//       // block.printData();
//
//
//        BlockAdd_2_1 blockplus = new BlockAdd_2_1(new String[][]{{"Sirka", "Vyska"}, {"Vyska", "Objem"}}, new String[][]{{"ID", "Vypocet"}, {"EE", "lala"}});
//
//        blockplus.printData();

            // cheknut 1 port
            // checnut 2 port
            // checknut samotne data (predtim bude insertInput)
            // calculate jesli sa spocitali....

        BlockAdd_2_1 blockAdd_2_1 = new BlockAdd_2_1();
        blockAdd_2_1.printData();
        blockAdd_2_1.setInputDataOnPort0(2.1);
        blockAdd_2_1.printData();
        blockAdd_2_1.setInputDataOnPort1(5.3);
        blockAdd_2_1.printData();
        blockAdd_2_1.calculate();
        blockAdd_2_1.printData();



    }
}



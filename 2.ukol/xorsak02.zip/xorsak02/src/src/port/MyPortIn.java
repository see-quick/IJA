package src.port;

import src.MyPort;

public class MyPortIn extends MyPort {


    public MyPortIn(String[] args) {
        super(args);
    }


    /*
    private int quantity;

    public InPort(String name, double value, int quantity) {
        super(name, value);
        this.quantity = quantity;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    @Override
    public String getName() {
        return super.getName();
    }

    @Override
    public void setName(String name) {
        super.setName(name);
    }

    @Override
    public double getValue() {
        return super.getValue();
    }

    @Override
    public void setValue(double value) {
        super.setValue(value);
    }

    @Override
    public void editPort() {
        super.editPort();
        // TODO : quantity... GUI
    }
    */
}
